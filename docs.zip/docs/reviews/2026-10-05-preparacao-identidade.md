# Preparação de identidade — GradualInfo Editorial

Data: 2026-10-05. Clone `a9_w_gradualinfo__iso`, branch
`chore/reconciliar-scope-spec-gates`. Decisões do dono aplicadas nesta rodada:
nome `GradualInfo Editorial`, identificador técnico `gradualinfo-editorial`,
marca pública `GradualInfo · gradualinfo.com.br`, CLI do Supabase fixada em
2.119.0, `timeout-minutes: 30` no job de banco, remoção das URLs do GitHub sem
inventar proprietário, e limpeza do vestígio do AQUA9.

**Nenhum banco, volume ou container foi apagado.** Os dois bancos locais foram
despejados em arquivo antes de qualquer mudança de identificador.

## 1. Referência visual: `template-aqua/` → `referencias/template-editorial/`

Rename feito com `git mv`, então o histórico acompanha: **119 arquivos** aparecem
como `R` no `git status`, nenhum como adição ou remoção.

| Ponteiro atualizado   | Arquivo                                                            |
| --------------------- | ------------------------------------------------------------------ |
| Ignore do Prettier    | `.prettierignore` (regra e comentário)                             |
| Ignore do ESLint      | `eslint.config.mjs`                                                |
| Exclusão do typecheck | `tsconfig.json` (regra e comentário)                               |
| Comentário do hook    | `.husky/pre-commit`                                                |
| Scope                 | `docs/scope/0001-mvp-portal-gradualinfo.md` (premissa 2 e fatia 6) |
| Índice de specs       | `docs/specs/INDICE.md` (duas passagens)                            |
| Spec do banco         | `docs/specs/md-0001-arquitetura-markdown-supabase.md`              |

O que **ficou** com o nome antigo, de propósito:

- `docs/reviews/*` e as linhas de histórico do `workflow/STATE.md`: são registro
  do que foi executado, com a data e o caminho da época. Reescrever registro é
  fabricar histórico.
- Nomes de branch e de arquivo de spec citados em `INDICE.md` e no scope
  (`feat/blog/template-aqua-velite`, `0001-blog-template-aqua.md`): são
  identificadores de artefatos que existem em outras branches. Trocá-los
  quebraria a citação por caminho.

**Nada visual mudou.** O diff real do `globals.css` do template tem **uma linha**,
e é um comentário: as oito variáveis de cor, as duas de fonte e os breakpoints
estão idênticos. Nenhum componente, layout, imagem ou composição foi tocado.

## 2. Identidade

| Arquivo                    | Antes                                    | Depois                                                                        |
| -------------------------- | ---------------------------------------- | ----------------------------------------------------------------------------- |
| `package.json:2`           | `gradualinfo`                            | `gradualinfo-editorial`                                                       |
| `package.json` (descrição) | "Boilerplate profissional — Next.js 16…" | "GradualInfo Editorial — portal editorial sobre tecnologia e consumo digital" |
| `supabase/config.toml:5`   | `project_id = "gradualinfo"`             | `project_id = "gradualinfo-editorial"`                                        |
| `wrangler.jsonc:13`        | `"name": "gradualinfo"`                  | `"name": "gradualinfo-editorial"`                                             |
| `README.md:1`              | `# Gradualinfo 🌊`                       | `# GradualInfo Editorial`                                                     |

O `README.md` ganhou também a pasta `referencias/` no mapa de pastas. O
`homepage` (`https://gradualinfo.com.br`) foi preservado: é o domínio público.

Nome de pacote não quebra o `pnpm install --frozen-lockfile`: o lockfile não
guarda o nome do pacote raiz, e a instalação foi executada depois da mudança
para comprovar — `Lockfile is up to date`. O `pnpm template:export` também
continua funcionando e passou a produzir `dist/gradualinfo-editorial-v2.0.0.zip`,
porque o nome do arquivo sai do `package.json`.

### Marcas dentro da referência visual

O template já trazia a marca trocada ("Gradual Info"), mas com **identidade de
agência herdada do boilerplate**, que contradiz o produto: tagline "Criação de
Sites, Landing Pages e Marketing para Empresas Locais", descrição de agência,
palavras-chave de captação de leads e mensagem de WhatsApp de diagnóstico
comercial. Isso é identidade, não design, então foi corrigido:

- "Gradual Info" → "GradualInfo" em **14 arquivos** (metadados, aria-labels de
  header e footer, autores dos 11 posts de exemplo, comentário da paleta).
- Tagline, descrição, palavras-chave e categoria → o posicionamento editorial do
  produto, com o slogan que o dono definiu.
- `legalName` → "GradualInfo Editorial". `whatsappMessage` → "Olá!".

O `README.md` do template, que credita o projeto de origem
(`codebucks27/Nextjs-tailwindcss-blog-template`), foi **preservado**: é atribuição
de terceiro, não vestígio do AQUA9.

## 3. Limpeza do vestígio do AQUA9

| Item                                                                               | Ação                                                                           |
| ---------------------------------------------------------------------------------- | ------------------------------------------------------------------------------ |
| `package.json` `repository` e `bugs` apontando para `github.com/aqua9/gradualinfo` | **removidos**; nenhum substituto foi inventado                                 |
| `scratch/rename-project.mjs`                                                       | **removido** (`git rm`) — era o script da operação de rename, artefato pontual |

`scratch/` ficou vazio e, como git não rastreia diretório vazio, sumiu do
repositório. As regras `scratch/**` no `.prettierignore`, no `eslint.config.mjs`
e no `tsconfig.json` foram **mantidas**: são convenção, não referência quebrada.

Varredura final por `aqua` fora de registros históricos: **zero** ocorrências de
identidade ou operação. `seed.sql` foi lido inteiro e não contém nenhum dado
herdado — só os dois usuários de teste e as **quatro fixtures**, que permanecem
intactas porque são o que prova a leitura pública por papel.

## 4. Banco: ordem executada e como recuperar

A instrução era preservar o banco atual e registrar o acesso antes de mudar o
`project_id`. A sequência foi esta, e nada foi apagado em nenhuma etapa:

1. **Dump do banco atual** (`project_id = gradualinfo`), com o stack no ar:
   `~/Downloads/gradualinfo-db-dump-antes-de-gradualinfo-editorial-2026-10-05.sql`
   — 396.786 bytes, 10.033 linhas, PostgreSQL 17.11, SHA-256
   `dfdaf38d6886830445c53e13da23ed8da5c79ffa977d4cb791464287111d63eb`. É o banco
   inteiro, todos os schemas.
2. **`pnpm supabase:stop`** — sem `--no-backup`. Os containers foram removidos, os
   volumes preservados; a própria CLI confirma que os dados ficaram em volume.
3. Mudança do `project_id` e do `name`, depois `pnpm supabase:start`: novos
   containers e **novos volumes** `supabase_*_gradualinfo-editorial`.

Como acessar e restaurar cada banco:

```bash
# Abrir o banco atual, que está no volume antigo, já parado
podman start supabase_db_website_aqua9.com.br   # stack legada do AQUA9
podman exec -it supabase_db_website_aqua9.com.br psql -U postgres -d postgres

# Restaurar o dump do GradualInfo no stack novo
podman exec -i supabase_db_gradualinfo-editorial psql -U postgres -d postgres \
  < ~/Downloads/gradualinfo-db-dump-antes-de-gradualinfo-editorial-2026-10-05.sql
```

O dump usa `\restrict`, que é sintaxe de `psql` 17 ou superior — restaurar com
uma versão anterior falha. O dump da base legada ficou em
`~/Downloads/aqua9-website_db-dump-2026-10-05.sql` (34.856 bytes, SHA-256
`f8b5b5eadbfd89672bb15dfdfd2407320723cdf3ace16b63f198f7051eb49c4a`, schemas
`public` e `supabase_migrations`).

### Inventário: o que existe, e por que nada foi apagado

| Origem                                | Containers                                                              | Volumes                              | Situação                                                      |
| ------------------------------------- | ----------------------------------------------------------------------- | ------------------------------------ | ------------------------------------------------------------- |
| GradualInfo, `gradualinfo-editorial`  | 12, **no ar**                                                           | 3 `supabase_*_gradualinfo-editorial` | atual                                                         |
| GradualInfo, `gradualinfo` (anterior) | removidos pelo `stop`                                                   | 3 `supabase_*_gradualinfo`           | preservados, com label `com.supabase.cli.project=gradualinfo` |
| AQUA9, `website_aqua9.com.br`         | 12, **parados** há 34 h a 2 dias                                        | 3 `supabase_*_website_aqua9.com.br`  | preservados                                                   |
| Sem atribuição                        | `pg-arena` (postgres:16, parado há 2 semanas), `seed-iso-pg-2026-10-02` | 4 volumes de hash                    | não atribuídos                                                |

**A base legada do AQUA9 tem conteúdo que não existe em mais lugar.** Inspecionada
em modo leitura, com o container do banco iniciado só para isso e parado de novo
em seguida:

| Tabela               | Linhas |
| -------------------- | ------ |
| `public.posts`       | **9**  |
| `public.admin_users` | 0      |
| `auth.users`         | 0      |

Os 9 posts são editoriais em pt-BR, com `published_at` real — "Agendado: review
do próximo MacBook Pro M4" (2026-11-02), "Chrome 130: novas APIs, performance e
ferramentas para devs", "Black Friday 2026: as melhores ofertas tech
verificadas". A tabela tem uma coluna `category` que o schema atual não tem.
Não é dado de exemplo descartável: apagá-lo perderia conteúdo, e o nome antigo no
repositório não autorizava essa decisão. O dump existe justamente para que a
decisão possa ser tomada com o conteúdo na mão.

Continua sem resposta porque o repositório não responde: **o projeto hospedado**.
Não há referência a ele em `.env.example`, `supabase/config.toml`,
`wrangler.jsonc`, `lib/env.ts` ou `next.config.ts`, e nenhuma URL `supabase.co`
antiga. Excluir exigiria a conta, e isso é ação do dono.

## 5. CLI fixada e CI

| Mudança                                                  | Onde                                 | Verificação                                              |
| -------------------------------------------------------- | ------------------------------------ | -------------------------------------------------------- |
| `pnpm dlx supabase` → `pnpm dlx supabase@2.119.0`        | os quatro wrappers em `package.json` | `pnpm dlx supabase@2.119.0 --version` responde `2.119.0` |
| `timeout-minutes: 20` → `30`, com o motivo em comentário | job `database`                       | é o único timeout novo do arquivo                        |

O motivo do pin é o mesmo que já pulou a migration `init`: foi um comportamento
da CLI, não o SQL, que quebrou o stack. Versão de ferramental pertence ao
repositório, não ao dia da execução.

## 6. Verificação depois das mudanças

| Comando                          | Resultado                                                                          |
| -------------------------------- | ---------------------------------------------------------------------------------- |
| `pnpm supabase:reset --local`    | exit 0, as duas migrations em ordem, seed semeado, sob o novo `project_id`         |
| `pnpm supabase:test`             | **`PASS`, `Tests=15`, exit 0**, com a CLI pinada                                   |
| `pnpm check:all`                 | typecheck, lint, formatação e **65 testes** verdes                                 |
| `pnpm install --frozen-lockfile` | `Lockfile is up to date`, com o nome novo                                          |
| `pnpm build:next`                | compila e gera as 7 rotas; o rename não arrastou a referência visual para o bundle |
| `pnpm template:export`           | `dist/gradualinfo-editorial-v2.0.0.zip` gerado; artefato removido depois           |
| `podman volume ls`               | 13 volumes — os 10 anteriores e os 3 novos; **nenhum removido**                    |

## 7. Pendências e limites

- **A CI no GitHub continua não executada.** Os quatro passos do job `database`
  foram conferidos por leitura e pelos mesmos comandos rodados aqui, e o timeout
  agora é 30 min; o comportamento em runner real é esperado, não observado.
- **O corpo do `README.md` ainda se apresenta como boilerplate** ("Boilerplate
  definitivo para aplicações Next.js… feito para ser o ponto de partida ideal para
  novos produtos"). Reescrever a documentação de produto é `/document`, não esta
  rodada; aqui só o título e o mapa de pastas, que são fatos.
- **`AGENTS.md` não citava o caminho do template**, então o rename não o
  desatualizou. Ele ainda descreve o `package.json` como boilerplate, o que é
  dívida do `/sync`.
- **Os quatro volumes sem nome e os dois containers órfãos** continuam sem
  atribuição. Nenhuma exclusão de volume foi tentada.
- As tarefas 1 a 5 do `md-0001` (transformação do schema, `posts_select_preview`,
  rejeição de `user_metadata`, testes de acesso efetivo por papel) seguem
  pendentes. `md-0002` continua `Proposed`: preparar identidade não autoriza a
  interface.
- **Nada foi commitado.** A árvore tem 119 renomes e 15 arquivos alterados ou
  novos, por decisão de não commitar sem pedido explícito.
