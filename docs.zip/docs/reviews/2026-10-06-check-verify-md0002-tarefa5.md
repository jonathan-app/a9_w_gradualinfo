# `/check verify` — md-0002 Tarefa 5 (e adiantamentos das Tarefas 6, 7 e 10)

**SHA Revisado:** `65df35f3100e3043810a83cc49cf2e234ad91d2f`
**Data:** 2026-10-06

## Escopo Verificado

Página de leitura do artigo (`/artigos/[slug]`) conforme especificação visual (`DESIGN.md`) e escopo (`docs/specs/md-0002-casca-editorial-home.md`), abordando a renderização segura do Markdown, tratamento de erros e recursos de SEO, Fontes Citadas e Sitemap.

## Cenários Avaliados

| AC           | Cenário                                                                                                                                                                              | Resultado                                | Evidência/Comentário                                                                                                                                                                                                                                                                                                                   |
| ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **AC-05**    | Renderização de Markdown, `<h1>` único e sanitização HTML (prevenção de execução de scripts embutidos no conteúdo).                                                                  | `PASS`                                   | `e2e/verify-md0002-tarefa5.spec.ts` validou a existência de apenas um `h1` na página (o título semântico foi convertido para `h2`), e a injeção `<script>alert(1)</script>` no markdown retornou escaped/segura.                                                                                                                       |
| **AC-06**    | 404 para slug inexistente vs. erro interno (500) se houver falha de banco de dados.                                                                                                  | `PASS (Visual)`<br>`UNVERIFIABLE (HTTP)` | O layout visual para "Página não encontrada" e "Algo deu errado" foi comprovado via testes end-to-end com simulação (renome da tabela `posts`). Contudo, o servidor de desenvolvimento do Next.js + Turbopack (streaming) mascara o status HTTP real (retorna 200). Status HTTP (404/500) não provados até teste em build de produção. |
| **AC-07**    | Rascunhos e posts agendados são inacessíveis para usuários anônimos (retornam "Página não encontrada").                                                                              | `PASS (Visual)`<br>`UNVERIFIABLE (HTTP)` | Igual ao `AC-06`. O conteúdo não é vazado, e a interface indica erro 404, mas o status code real não foi capturado no ambiente dev.                                                                                                                                                                                                    |
| **AC-10/11** | Metadata, canonical tag, Open Graph e inserção de JSON-LD seguro (sem quebra de HTML se houver aspas). Sitemap não expõe drafts/agendados e mapeia `lastModified` para `updated_at`. | `PASS`                                   | Validados no `verify-md0002-tarefa5.spec.ts`. Canonical URL correto, meta title preenchido, `application/ld+json` bem formatado (mesmo com aspas/tags maliciosas). O endpoint `/sitemap.xml` retornou as URLs de posts publicados.                                                                                                     |
| **AC-12**    | Acessibilidade via Axe (Core Web Vitals para acessibilidade, contraste, teclado, navegação).                                                                                         | `UNVERIFIABLE`                           | Não coberto pelo `verify-md0002-tarefa5.spec.ts`. Pendente de uma suíte com `@axe-core/playwright`.                                                                                                                                                                                                                                    |
| **AC-13**    | Exibição condicional de fontes citadas. Ocultado se `fontes_citadas` é array vazio; exibido com links `noopener noreferrer`.                                                         | `PASS`                                   | O script validou artigos com fontes e sem fontes. Na ausência de fontes, a tag `<h2>Fontes</h2>` não é renderizada.                                                                                                                                                                                                                    |

## Resumo do `pnpm check:all` e `supabase:test`

- Linters e typechecks passaram integralmente (0 erros).
- Unit tests (`vitest`) rodaram sem quebras.
- Banco local restaurado, sem artefatos corrompidos pelo uso da alteração forçada na simulação de erro de banco (`pnpm supabase:reset && pnpm supabase:test` -> 63/63 aprovados).

## Conclusão

A **Tarefa 5** (assim como as entregas de SEO e Sitemap) passou na verificação de comportamento, exceção feita a restrições do tooling de dev-server (status HTTP não testáveis via Node local).
O avanço para a **Tarefa 8** (Preview HTTP) está autorizado. As pendências (Axe e validação HTTP) ficam sinalizadas para o build final.
