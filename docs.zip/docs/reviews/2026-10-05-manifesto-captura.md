# Manifesto de captura — isolamento em clone

> Registro da transferência de artefatos da árvore compartilhada para um clone
> separado. Data: 2026-10-05. Motivo: três outras sessões de agente estavam
> escrevendo na árvore compartilhada (ver Finding 0 da auditoria), o que torna
> qualquer escrita local instável.

## Origem e destino

| Item               | Valor                                                            |
| ------------------ | ---------------------------------------------------------------- |
| Árvore de origem   | `/home/jonathan/Workspace/Projetos_Ativos/a9_w_gradualinfo`      |
| Clone              | `/home/jonathan/Workspace/Projetos_Ativos/a9_w_gradualinfo__iso` |
| Comando            | `git clone --no-local`                                           |
| SHA de origem      | `bec25aa50fb4779d8638a5a0cbabb7ace37fb2bd`                       |
| SHA no clone       | `bec25aa50fb4779d8638a5a0cbabb7ace37fb2bd` — **idêntico**        |
| Branch de trabalho | `chore/reconciliar-scope-spec-gates`                             |

`--no-local` evita referência por hardlink: o clone não compartende inode com a
origem, então escrita no clone não toca a árvore compartilhada.

## O que um clone não herda

Um clone comum traz **apenas o que está commitado**. No momento da captura, a
origem tinha 21 entradas em `git status` e nenhum commit além de `bec25aa` — ou
seja, specs, scope, auditoria, `kilo.json` e os dois scripts do gate eram
inteiramente invisíveis para o clone. Por isso a transferência abaixo é
explícita, arquivo a arquivo, com verificação de integridade.

## Integridade da captura

SHA-256 calculado **duas vezes** na origem, antes e depois da cópia, para detectar
mudança durante o transporte. Resultado: **nenhum arquivo mudou** entre `t0` e
`t1`. Os hashes abaixo são os de `t1` e conferem com os bytes presentes no clone.

| SHA-256                                                            | Artefato                                                |
| ------------------------------------------------------------------ | ------------------------------------------------------- |
| `71def70717f5745709ccd6e3d3fe8f4c207a3f6256bbe3684210a98c808f85d8` | `workflow/STATE.md`                                     |
| `7b8b1db1d4c0b5e2450e1dc197630a7ca77d8b9293d3d65fa59e3bd33da05caf` | `docs/scope/0001-mvp-portal-gradualinfo.md`             |
| `0b9838413f1388226e4efd022248ebbc72acd0f7252f73b6859e8f999749eece` | `docs/reviews/2026-10-04-auditoria-skills-estrutura.md` |
| `0f23a3505bfd55e5200f3841ad42da5b751dc0a4b6c5eaf6ae6be81e07e25dfa` | `docs/specs/md-0001-arquitetura-markdown-supabase.md`   |
| `a773b6eb29ca1450393be3207b057a668f2aa2c3e463b7755de2a13fcddcb82b` | `docs/specs/md-0002-casca-editorial-home.md`            |
| `ca22e8fa719707ae4f3df466bb32532dd93d43661f0f6f27e080575b3294d8d8` | `docs/workflow/arquitetura-editorial.md`                |
| `55be3ea8033f8f599f7da1cf3d9520a19861f4fecd81a762c53f475a9ba29c30` | `kilo.json`                                             |
| `77126d55934d849c48d5e57ff4b1cabb3e99e174e84fd5634a05418177e9c352` | `scripts/check-decision.mjs`                            |
| `a349804f8d725a385ff7b17a76b76e946027ae2535b007b1f44917e3bd517c61` | `scripts/check-gate.mjs`                                |

## Autoria: o que é deste trabalho e o que é herdado

Transferir um arquivo ligado à tarefa **não prova** que a alteração é do autor
desta tarefa. Só `workflow/STATE.md` é rastreado no commit base; os outros oito
arquivos são novos e chegam sem histórico de autoria. Dentro do `STATE.md` há
entradas de **duas** sessões — as linhas 21, 22 e 23 do histórico foram escritas
por outra sessão (migração de skills, arquitetura editorial, refatoração do
scope) e foram preservadas, não reescritas.

O que esta sessão alterou dentro desses arquivos:

| Arquivo                      | Alteração                                                                                                 |
| ---------------------------- | --------------------------------------------------------------------------------------------------------- |
| `workflow/STATE.md`          | Retificação do `/check` (desbloqueado), do Kilo (descoberta não verificada) e colisão de ID `0001`/`0002` |
| `docs/scope/…gradualinfo.md` | Revisão 3: SEO básico na fatia 4, comentários para pós-MVP, Markdown reexplicado, seção de colisão de ID  |
| `docs/reviews/…estrutura.md` | Finding 8 superado com prova por execução; Finding 3 e Finding 2 retificados                              |

## Verificações executadas no clone

| Verificação                                              | Resultado                   |
| -------------------------------------------------------- | --------------------------- |
| `prettier --check` nos 9 artefatos                       | passa                       |
| `node scripts/check-decision.mjs` com lista de ACs vazia | `exit 1`, `approved: false` |
| `…` com um AC `UNVERIFIABLE`                             | `exit 1`, `approved: false` |
| `…` com um AC `PASS` sem evidência                       | `exit 1`, `approved: false` |
| `…` com um `BLOCKER`                                     | `exit 1`, `approved: false` |
| `…` com AC válido e sem finding                          | `exit 0`, `approved: true`  |

## O commit foi barrado — e a falha é herdada

`.husky/pre-commit` roda `prettier --check --ignore-unknown .` e `pnpm typecheck`.
O commit **falhou**, e a causa não é deste trabalho:

| Evidência                                                                                 | Resultado                                                                                 |
| ----------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| `prettier --list-different .` com os 10 artefatos da tarefa stageados                     | 55 em `template-aqua/`, 2 em `scripts/`, 1 em `scratch/`, 1 em `components/`, 1 em `app/` |
| `prettier --check` só nos 10 artefatos desta tarefa                                       | **passa**                                                                                 |
| `prettier --check --ignore-unknown .` em `bec25aa` **sem nenhum artefato deste trabalho** | **falha nos mesmos 60 arquivos**                                                          |

Ou seja: o commit base `bec25aa` já reprova o próprio portão. O pre-commit não
está sinalizando erro desta tarefa — está sempre reprovando, porque
`template-aqua/` (55 arquivos) e `scratch/` estão versionados dentro do
boilerplate e nunca foram formatados.

Nenhum arquivo foi formatado globalmente para contornar isso: os 60 arquivos são
alheios à tarefa, e mexer neles seria levar uma alteração de 55 arquivos de
terceiro para dentro do mesmo commit.

**Estado do trabalho:** os 10 artefatos estão **staged** na branch
`chore/reconciliar-scope-spec-gates`, sem commit. Commit com `--no-verify`
bypassaria um portão quebrado, e isso é decisão de quem responde pelo gate — não
minha. Duas saídas, ambas do dono do projeto: corrigir os 60 arquivos e
restaurar o portão, ou autorizar explicitamente o bypass neste commit.

## Limites deste isolamento

- Nenhum arquivo apagado da árvore compartilhada foi restaurado. As exclusões
  anteriores continuam sem explicação de causa, e o isolamento não as explica.
- Nenhuma formatação global foi rodada na árvore compartilhada.
- Nada foi enviado: sem push, sem merge, sem deploy. A branch existe só local.
- A árvore compartilhada segue sendo escrita por outras sessões; este clone não
  passa a ser a fonte da verdade sem decisão de integração.
