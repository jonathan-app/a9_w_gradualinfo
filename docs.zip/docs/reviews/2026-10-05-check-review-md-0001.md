# /check review — md-0001, tarefas 1 a 5

Data: 2026-10-05. Autor: verificação local; decisões do dono confirmadas.

## Resumo da entrega

| Item                 | Estado                                                                                                               |
| -------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **Schema editorial** | Transformado por `alter table` (não recriado), 12 colunas do AC-01 + `created_at` preservada                         |
| **RLS**              | Duas policies: `posts_select_public` (preservada, com agendamento) + `posts_select_preview` (`app_metadata.preview`) |
| **Escrita**          | `revoke all` + `grant select` para `anon`/`authenticated` → sem INSERT/UPDATE/DELETE; `service_role` mantém tudo     |
| **Testes**           | 15 → **63 asserções**; acesso efetivo por 5 papéis; sabotagens 5/63 e 7/63; `user_metadata` rejeitado                |
| **AC-06**            | `pg_dump --schema-only` idêntico (8992 linhas) do zero vs. sobre estado de `main` com 3 linhas legadas               |
| **Stack**            | Reset limpo, PASS 63/63, CLI 2.119.0 pinada                                                                          |

## Qualidade do código

- Migrations idempotentes, ordem: coluna nulável → backfill → endurecer → CHECK → COMMENT
- `CHECK` de `fontes_citadas` via função `immutable` com `search_path = ''` (não SECURITY DEFINER)
- Backfill não inventa conteúdo editorial: `sem-editoria`, raiz do domínio como capa, "GradualInfo Editorial" como autor
- `created_at` e 3 índices antigos preservados por decisão do dono
- 4 policies `*_own` removidas na migration do schema por dependência de `author_id` (erro `2BP01`)

## Riscos e mitigações

| Risco                                                 | Status                                                                                                                                                 |
| ----------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| RLS desligada expõe rascunho se `grant select` existe | **Documentado**: proteção de leitura é a RLS; `grant` protege escrita. Mitigação futura = não conceder select e usar SECURITY DEFINER, mas muda modelo |
| Fixtures com capa placeholder (imagem não existe)     | Identificado; conteúdo real virá na fatia 6 com imagem válida                                                                                          |
| 9 posts AQUA9 sem destino                             | Orientação: **não importar**; exclusão do banco legado exige ação do dono (conta)                                                                      |
| `md-0002` sem aceite                                  | Permanece `Proposed`; preview precisa token + cookie + timingSafeEqual                                                                                 |

## Conformidade com AGENTS.md

- RLS ligada em toda tabela ✅
- Policy por operação (select público, select preview, sem insert/update/delete para não privilegiados) ✅
- `auth.getUser()` para autorização; `getSession()` só para exibição — não há código de aplicação nesta entrega ✅
- Server Component por padrão, `'use client'` só em folha — não há código de aplicação ✅
- `cn()` para `className` condicional — não há código de aplicação ✅
- Variáveis de ambiente tipadas em `lib/env.ts` — `SUPABASE_PREVIEW_TOKEN` lido lá para o caminho de preview (futuro) ✅
- `pnpm check:all` passa (typecheck, lint, prettier, 65 testes) ✅

## Gaps conhecidos

1. **COMMENT da tabela corrigido** via migration nova ✅
2. **RLS desligada + grant select** expõe leitura — mitigado por não desligar RLS; documentado no relatório
3. **Exclusão do banco AQUA9** — pendente de ação do dono (conta Supabase)
4. **CI remota** — não executada; job `database` configurado com 63 asserções, timeout 30 min, CLI pinada

## Próximos passos condicionados ao dono

| Decisão             | Ação                                                                                                                            |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| Aceitar `md-0002`   | `/develop` da `md-0002`: preview (token, cookie, timingSafeEqual), rota `/artigos/[slug]`, exibição de `fontes_citadas` (AC-07) |
| Excluir banco AQUA9 | Ação manual na conta Supabase; dump já salvo                                                                                    |
| Commit              | Separar: preparação de identidade (119 renomes) + alteração de banco (4 migrations, suíte, seed)                                |

## Aprovação

Esta revisão **não** constitui aceite da `md-0002`. A entrega das tarefas 1 a 5 do `md-0001` está **implementada, testada e verificada** contra todos os 8 ACs, com evidência registrada em `docs/reviews/2026-10-05-check-verify-md-0001.md`.
