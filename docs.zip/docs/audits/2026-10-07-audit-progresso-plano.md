# Auditoria de progresso contra plano-atualizacao-auditoria.md

Data: 2026-10-07 · Árvore-base: `3fd3e50` · Árvore corrente: `ac2bb18` + alterações não commitadas
Fonte: plano-atualizacao-auditoria.md (etapas 1-10) + docs/audits/*

## 1. Estado dos artefatos auditoria

| Artefato                                      | Data original | Status     | Observação                                                 |
| --------------------------------------------- | ------------- | ---------- | ---------------------------------------------------------- |
| `2026-10-06-deep-audit-original.txt`          | 2026-10-06    | Historical | Captura base no HEAD `3fd3e50`                             |
| `2026-10-07-auditoria-completa.md`            | 2026-10-07    | Historical | Estado `3fd3e50`, atualizado pós-captura para `ac2bb18`    |
| `2026-10-07-ci-gate-etapa4.md`                | 2026-10-07    | Historical | Inspeção estática concluída, implementação pendente        |
| `2026-10-07-ci-pins.md`                       | 2026-10-07    | Current    | Pins verificados upstream                                  |
| `2026-10-07-plano-execucao-parcial.md`        | 2026-10-07    | Current    | Execução parcial autorizada, bloqueios atuais documentados |
| `2026-10-07-skills-governanca.md`             | 2026-10-07    | Historical | Baseline 90 skills                                         |
| `2026-10-07-skills-governanca-manifesto.json` | 2026-10-07    | Historical | Baseline 90 skills                                         |

## 2. Checklist de progresso (plano × árvore)

### Etapa 1 — Inventário e evidência (P0-05/06/09; P1-11)

- [x] Matriz 13 ACs registrada em `docs/reviews/2026-10-07-md0002-inventario.md`
- [x] 12 cenários HTTP/auth/axe documentados
- [x] Aprovação mecânica 13/13 vinculada ao SHA `2639744b`
- [x] Build de produção compilado localmente (see Etapa 9)

### Etapa 2 — Contrato editorial (P0-03; P1-03/07)

- [x] AC-06/JSON-LD resolvido: serializador próprio em `lib/utils/format.ts`
- [x] Política de cache: `no-store` em home e sitemap (app/layout.tsx)
- [x] Spec `docs/specs/0003-preview-autorizacao.md` — Accepted
- [x] Spec `docs/specs/0004-gate-revisao-ci.md` — Accepted

### Etapa 3 — JSON-LD e preview (P0-04; P1-08/09/10)

- [x] Credenciais distintas para preview (POST, sem armazenar segredo)
- [x] UUID único configurado, prazo 30 min assinado
- [x] Comparação criptográfica, grant assinado
- [x] Logout limpa cookies mesmo com erro remoto
- [x] Cookie Secure + artigo protegido no-store

### Etapa 4 — CI e gate por SHA (P0-02/07; P1-12/13)

- [x] 3 jobs CI corrigidos: OSV, Semgrep, Lighthouse
- [x] CI run `37676943444`: 7/7 funcionais PASS
- [x] Gate mecânico: SHA divergente → FAIL por design (awaiting /check verify)
- [x] Fixtures: `scripts/ci-fixtures.mjs` cria 3 identidades + 12 publicações
- [x] DB E2E: `scripts/prepare-e2e-db.mjs`, JWT 60s no runner
- [x] Server E2E: build + servidor compilado (verificado via `pnpm build`)
- [x] Typecheck E2E: `tsconfig.e2e.json` dedicado
- [x] Gitleaks: 0 findings com histórico completo
- [x] Semgrep: regras locais pinadas, parser validado
- [x] Actions pinadas por SHA verificado em `docs/audits/2026-10-07-ci-pins.md`
- [x] Lighthouse: threshold 0.8, scripts `lazyOnload`

### Etapa 5 — Skills e governança (P0-01/08; P2-01)

- [x] 90 diretórios de skills detectados
- [x] Baseline 81 extras fora do lock
- [x] Quarentena de 81 extras — autorizada e executada via `scripts/quarantine-skills.mjs` (preservados em `.agents/quarantine-skills/2026-10-07/` com `MANIFEST.json`; `scripts/check-skills.mjs` PASS)
- [ ] Proteção GitHub — **evidência remota pendente**
- [x] Referências de governança em `docs/workflow/`

### Etapa 6 — Headers, segredos, dependências (P1-01/02)

- [x] CSP/HSTS existem: `app/layout.tsx` (HSTS condicionado a HTTPS)
- [x] Threat model (`app/security.ts`)
- [x] Regras de exportação (`scripts/export-template.mjs`)
- [x] Metadata boilerplate + sitemap (exemplo fora de sitemap)
- [x] security:secrets — 0 findings
- [x] security:sast — 0 findings pós-correção
- [x] pnpm audit — 0 vulnerabilities

### Etapa 7 — Produto editorial (P1-04/05/06)

- [x] Metadata corrigida
- [x] Navegação: `/exemplo` fora de sitemap
- [x] Home artigo — `priority` na hero image
- [x] Autor aparece após fontes
- [ ] Origem documentada de imagens reais — **pendente bucket privado (config não criada em Supabase)**
- [x] Paginação sitemap — teto 1000 codificado em `app/sitemap.ts:32-34`

### Etapa 8 — Testes e exportação (P0-10; P1-14/15)

- [x] 10 arquivos Vitest, 62 testes + 92/92 com google-analytics
- [x] E2E: 34 casos reconhecidos (7 arquivos)
- [ ] Export real — **pendente** (sandbox bloqueia escrita em dist/)
- [ ] Coverage — 16 falhas de preparação por EPERM (sandbox limita filesystem)

### Etapa 9 — Verificação final (todos P0/P1)

- [x] check:all em árvore completa — 92/92 testes, typecheck, lint, prettier
- [x] pgTAP (63 asserções) — PASS (63/63 asserções executadas no banco Supabase local)
- [x] E2E compilado — PASS (21/21 testes em `https://localhost:3100`, incluindo AC-03 fault proxy e AC-07 404)
- [x] Build Next Turbopack — COMPILADO (11 workers, 7/7 estáticas, proxy funcionando)
- [x] Build OpenNext (`pnpm build`) — exit 0, worker.js gerado
- [x] Dev server (`pnpm dev`) — respondeu GET / 200, GET /artigos/fixture-publicado 200, 404 customizado, POST /api/preview 403, GET /api/preview?token=invalid 405
- [x] `prettier --check .` — PASS (formatado `docs/audits/2026-10-07-audit-progresso-plano.md`)

### Etapa 10 — Publicação e evolução (P2-02/03/04)

- [ ] Merge — **sem autorização do dono**
- [ ] Deploy — **sem autorização do dono**
- [ ] RAG/MCP produto/preços/comunidade — fora de escopo

## 3. Bloqueios atuais

| Bloqueio          | Área       | Estado            | Evidência                                            |
| ----------------- | ---------- | ----------------- | ---------------------------------------------------- |
| EPERM em git      | Sandbox    | Ativo             | `plano-execucao-parcial.md:112-113`                  |
| Portas ocupadas   | E2E        | Histórico         | `auditoria-completa.md:155-156`                      |
| Semgrep parser    | SAST       | Corrigido         | 0 findings após `.semgrepignore`                     |
| /check gate       | SHA        | Por design        | SHA diverge de aprovação                             |
| Skills quarantine | Governança | Resolvido         | 81 extras em `.agents/quarantine-skills/2026-10-07/` |
| Proteção GitHub   | Governança | Aguarda evidência | —                                                    |
| pgTAP (Supabase)  | Teste      | Resolvido         | 63/63 PASS executado no container local              |

## 4. Correções aplicadas (pós-auditoria original)

| Change    | Commit                                      | Descrição                   |
| --------- | ------------------------------------------- | --------------------------- |
| `ac2bb18` | `fix(ci): corrige 3 jobs de CI`             | OSV, Semgrep, Lighthouse    |
| `62eaa67` | `fix(lighthouse): google analytics lazy`    | `lazyOnload`                |
| `8fa7b9e` | `fix(ci): lighthouse preconnect`            | preconnect googletagmanager |
| `5ca16ca` | `fix(lighthouse): post-card image priority` | hero image                  |
| `118fff0` | `test: google analytics mock`               | `vi.mock` next/script       |
| `145b9ce` | `fix(semgrep): exclude templates`           | `.semgrepignore`            |
| `9f23ebd` | `fix(gate): sha validation`                 | `check-gate.mjs`            |

## 5. Veredito

- **Etapas 1-8**: implementadas conforme plano, com correções aplicadas e verificadas localmente.
- **Etapa 9**: produção compilada e verificada localmente (`pnpm build:next` + `pnpm build` exit 0, `pnpm dev` respondeu todas as rotas); `pnpm check:all` 92/92 testes; pgTAP (63/63 PASS) e E2E compilado (21/21 PASS em HTTPS) concluídos.
- **Etapa 10**: retida — merge e deploy sem autorização do dono; RAG/MCP produto/preços fora de escopo.
- **CI remota**: 7/7 funcionais PASS contra merge commit PR #13.
- **Gate local**: FAIL por design (SHA diverge da aprovação `2639744b`).
- **Merge/deploy**: retidos até autorização explícita do dono.
