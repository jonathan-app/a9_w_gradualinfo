# Etapa 4, auditoria de CI e gate por SHA

Data: 2026-10-07. Estado: inspeção estática concluída, implementação pendente.
Autorização: linha 4 do plano apresentada pelo dono. Dependência: etapas 1 a 3.
A etapa 3 permanece Blocked por contrato incompleto de preview.
Nenhum workflow, script de gate ou código de produto foi alterado.

## Achados

| Área               | Evidência atual                                                                                                                                                          | Correção necessária                                                                                                                               |
| ------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| Vínculo da decisão | `scripts/check-gate.mjs` lê apenas `approved` do JSON e compara HEAD com o argumento `--commit`; ignora SHA e árvore do artefato.                                        | Conferir revisão registrada no artefato contra revisão realmente verificada. O argumento da CI não pode fornecer a revisão supostamente aprovada. |
| Completude         | `scripts/check-decision.mjs` aprova qualquer lista não vazia com PASS e texto de evidência. Não compara conjunto esperado, duplicatas ou IDs extras.                     | Conjunto exato de ACs da spec, sem omissões, extras ou duplicatas. Validar tipos e rejeitar entrada malformada.                                   |
| Contrato CI        | `verify-result.json` contém cinco ACs UNVERIFIABLE, sem decisão `approved`, SHA ou árvore; CI passa esse arquivo direto ao gate.                                         | Separar resultados, decisão e aprovação; rejeitar artefato ausente, incompleto, reprovado ou vinculado a outra revisão.                           |
| Banco E2E          | Job `e2e` não inicia Supabase nem aplica migrations/seed. Job `database` é outro runner.                                                                                 | Preparar banco e fixtures no runner E2E, com identidade de preview e credenciais descartáveis segundo contrato da etapa 3.                        |
| Servidor E2E       | `playwright.config.ts` executa `pnpm dev`, inclusive com CI definida.                                                                                                    | Executar build e servidor compilado no job, sem reusar servidor externo.                                                                          |
| Tipos E2E          | `tsconfig.json` exclui `e2e/**`; não há script dedicado em `package.json`.                                                                                               | Typecheck dedicado para testes e configuração Playwright.                                                                                         |
| Segredos           | Nenhum job executa gitleaks.                                                                                                                                             | Scan de histórico completo e árvore, com relatório redigido e falha preservada.                                                                   |
| Wrapper gitleaks   | `scripts/run-gitleaks.mjs` sobrescreve findings a cada scan; o último resultado pode ocultar achado histórico e códigos de erro não são tratados integralmente.          | Acumular resultados e falhar para achados de qualquer scan ou erro operacional.                                                                   |
| Semgrep            | CI usa pacotes remotos, sem `security/semgrep.yml`. Wrapper local usa faixa `semgrep@1`, referencia `fs`, `spawnSync` e `path` sem imports e não propaga status de erro. | Executar regras locais com scanner explicitamente pinado, imports válidos e tratamento de erro que bloqueia.                                      |
| Ferramentas        | Actions referenciam tags; Lighthouse e wait-on via `npx` sem versão.                                                                                                     | Fixar actions em SHAs verificáveis e ferramentas em versões exatas. Sem declarar resolução remota verificada nesta rodada.                        |
| Lighthouse         | Job não prepara banco ou fixtures e coleta artigo de fixture.                                                                                                            | Garantir artigo realmente publicado no banco do próprio runner antes da coleta.                                                                   |

## Reprodução e limites

Reprodução em repositório descartável foi tentada para aprovação com SHA
antigo e conjunto vazio, e resultado com AC único e evidência inexistente.
O sandbox bloqueou `spawnSync git` com EPERM antes de executar os gates.
A repetição fora do sandbox foi solicitada e permanece pendente nesta captura.
Os achados acima são estáticos, não resultados de execução remota ou PASS.
Nenhuma suíte, CI remota, scanner ou build foi executado nesta auditoria.

## Próximo passo

Resolver contrato do preview em `/architect` e implementar etapa 3.
Antes da etapa 4, registrar contrato aceito do artefato de decisão:
origem canônica do conjunto de ACs, SHA e árvore avaliados, vínculo da spec,
origem confiável da aprovação e tratamento de relatórios legados.
A decisão mecânica de PASS não substitui aprovação editorial ou autorização
para merge/deploy. Preservar relatórios antigos como históricos.
