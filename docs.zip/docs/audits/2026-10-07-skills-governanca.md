# Etapa 5, skills e governança local

Data: 2026-10-07. Estado: inventário concluído, reconciliação pendente.

## Evidência

O lock contém 9 skills. A instalação local tem 90 diretórios,
com 81 fora do lock e 0 nomes do lock ausentes.
O manifesto ao lado registra os nomes, presença de SKILL.md, SHA-256 do
arquivo atual e computedHash do lock. Não comparar esses dois hashes como
versões: ainda não foi estabelecido o algoritmo de computedHash do CLI.
Nenhuma allowlist local foi encontrada nesta inspeção. Existência em disco
não prova descoberta no cliente nem execução da skill.

## Contradições documentais

| Documento             | Afirmação                                                          | Evidência local                                                                                                            |
| --------------------- | ------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------- |
| skills-load-config.md | Níveis 2 e 3 não estão instalados                                  | Diversas skills desses níveis existem em .agents/skills, incluindo supabase, github-actions e security.                    |
| BRANCHES.md           | main protegida, CODEOWNERS e quatro checks ativos                  | .github/CODEOWNERS e docs/BRANCH_PROTECTION.md ausentes; workflow atual tem oito jobs, sem confirmação remota da proteção. |
| BRANCHES.md           | pnpm protect:main e scripts/setup-branch-protection.sh disponíveis | Script ausente e comando não consta em package.json.                                                                       |
| Skills do ciclo       | docs/workflow/governance.md e conventions.md como contrato         | Ambos ausentes na árvore inspecionada. As referências não podem ser tratadas como instruções lidas.                        |

## Limites e proposta

Não remover skills extras, atualizar o lock, criar CODEOWNERS com usuário
inventado, alterar proteção remota ou substituir conteúdo curado de AGENTS.md.
Recomenda-se reconciliar a documentação com o inventário e escolher uma
allowlist explícita antes de criar o verificador. Esse verificador deverá
rejeitar skill extra, skill ausente e alteração do conteúdo controlado, com
algoritmo de hash documentado e casos negativos. A versão só poderá ser
comparada após conferir o formato real do lock do instalador.

Proteção GitHub permanece UNVERIFIABLE, sem chamada remota nesta rodada.
A etapa 5 não está concluída: verificador, reconciliação e prova de versão
continuam pendentes. Nenhum arquivo de configuração ou skill foi alterado.
